# Visualização de Dados com Python

Um gráfico para cada arquivo de dados, cada um gerado por **um script independente**
(Python + pandas, matplotlib, seaborn e scipy).

## Estrutura

```
.
├── data/        # arquivos CSV de entrada
├── scripts/     # um script por gráfico
├── graficos/    # imagens PNG geradas
├── requirements.txt
└── README.md
```

## Gráficos

| Script | Dados | Tipo de gráfico | Resultado |
|---|---|---|---|
| `scripts/01_barras.py` | `dados_barras.csv` | Barras agrupadas (categoria × região) | `graficos/01_barras.png` |
| `scripts/02_boxplot.py` | `dados_boxplot.csv` | Boxplot de salários por departamento | `graficos/02_boxplot.png` |
| `scripts/03_dispersao.py` | `dados_dispersao.csv` | Dispersão altura × peso, por sexo | `graficos/03_dispersao.png` |
| `scripts/04_distribuicao.py` | `dados_distribuicao.csv` | Histograma + densidade (idade) | `graficos/04_distribuicao.png` |
| `scripts/05_frequencia.py` | `dados_frequencia.csv` | Frequência por tipo de atendimento | `graficos/05_frequencia.png` |
| `scripts/06_heatmap.py` | `dados_heatmap.csv` | Mapa de calor dia × horário | `graficos/06_heatmap.png` |
| `scripts/07_linhas.py` | `dados_linhas.csv` | Linhas: vendas ao longo do tempo, por loja | `graficos/07_linhas.png` |
| `scripts/08_pizza.py` | `dados_pizza.csv` | Pizza: faturamento por canal | `graficos/08_pizza.png` |
| `scripts/09_regressao.py` | `dados_regressao.csv` | Regressão linear renda × gasto (com R²) | `graficos/09_regressao.png` |

## Como executar

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# um gráfico
python scripts/01_barras.py

# todos de uma vez
for s in scripts/*.py; do python "$s"; done
```

Os scripts usam caminhos relativos à raiz do projeto, então podem ser executados
de qualquer diretório.
