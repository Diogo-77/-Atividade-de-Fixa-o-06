"""Histograma com curva de densidade: distribuição de idade dos clientes."""
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

RAIZ = Path(__file__).resolve().parent.parent
df = pd.read_csv(RAIZ / "data" / "dados_distribuicao.csv")

media = df["idade"].mean()
mediana = df["idade"].median()

sns.set_theme(style="whitegrid")
fig, ax = plt.subplots(figsize=(10, 6))
sns.histplot(df["idade"], bins=15, kde=True, color="steelblue", ax=ax)
ax.axvline(media, color="crimson", linestyle="--", label=f"Média: {media:.1f}")
ax.axvline(mediana, color="darkgreen", linestyle=":", label=f"Mediana: {mediana:.1f}")

ax.set_title("Distribuição da idade dos clientes", fontsize=14, weight="bold")
ax.set_xlabel("Idade (anos)")
ax.set_ylabel("Número de clientes")
ax.legend()

fig.tight_layout()
saida = RAIZ / "graficos" / "04_distribuicao.png"
fig.savefig(saida, dpi=150)
print(f"Gráfico salvo em {saida}")
