"""Gráfico de pizza: participação de cada canal no faturamento."""
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

RAIZ = Path(__file__).resolve().parent.parent
df = pd.read_csv(RAIZ / "data" / "dados_pizza.csv")
df = df.sort_values("faturamento", ascending=False)

fig, ax = plt.subplots(figsize=(8, 8))
ax.pie(df["faturamento"], labels=df["canal_venda"], autopct="%1.1f%%",
       startangle=90, counterclock=False,
       colors=plt.cm.Set2.colors, pctdistance=0.8,
       wedgeprops={"edgecolor": "white", "linewidth": 2},
       textprops={"fontsize": 11})

total = df["faturamento"].sum()
ax.set_title(f"Faturamento por canal de venda\n(Total: R$ {total:,.0f})"
             .replace(",", "."), fontsize=14, weight="bold")

fig.tight_layout()
saida = RAIZ / "graficos" / "08_pizza.png"
fig.savefig(saida, dpi=150)
print(f"Gráfico salvo em {saida}")
