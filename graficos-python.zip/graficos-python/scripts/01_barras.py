"""Gráfico de barras agrupadas: vendas médias por categoria e região."""
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

RAIZ = Path(__file__).resolve().parent.parent
df = pd.read_csv(RAIZ / "data" / "dados_barras.csv")

sns.set_theme(style="whitegrid")
fig, ax = plt.subplots(figsize=(10, 6))
sns.barplot(data=df, x="categoria", y="vendas_medias", hue="regiao",
            palette="viridis", ax=ax)

for container in ax.containers:
    ax.bar_label(container, fmt="%.0f", fontsize=8, padding=2)

ax.set_title("Vendas médias por categoria e região", fontsize=14, weight="bold")
ax.set_xlabel("Categoria")
ax.set_ylabel("Vendas médias")
ax.legend(title="Região")

fig.tight_layout()
saida = RAIZ / "graficos" / "01_barras.png"
fig.savefig(saida, dpi=150)
print(f"Gráfico salvo em {saida}")
