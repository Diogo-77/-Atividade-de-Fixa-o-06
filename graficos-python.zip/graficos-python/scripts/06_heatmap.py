"""Mapa de calor: movimento de clientes por dia da semana e horário."""
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

RAIZ = Path(__file__).resolve().parent.parent
df = pd.read_csv(RAIZ / "data" / "dados_heatmap.csv")

dias = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]
matriz = (df.pivot(index="dia_semana", columns="horario",
                   values="movimento_clientes")
            .reindex(dias))

fig, ax = plt.subplots(figsize=(10, 6))
sns.heatmap(matriz, annot=True, fmt="d", cmap="YlOrRd", linewidths=0.5,
            cbar_kws={"label": "Movimento de clientes"}, ax=ax)

ax.set_title("Movimento de clientes por dia e horário",
             fontsize=14, weight="bold")
ax.set_xlabel("Horário")
ax.set_ylabel("Dia da semana")

fig.tight_layout()
saida = RAIZ / "graficos" / "06_heatmap.png"
fig.savefig(saida, dpi=150)
print(f"Gráfico salvo em {saida}")
