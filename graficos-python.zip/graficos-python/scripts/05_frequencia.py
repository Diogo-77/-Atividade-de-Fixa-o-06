"""Gráfico de frequência: quantidade de chamados por tipo de atendimento."""
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

RAIZ = Path(__file__).resolve().parent.parent
df = pd.read_csv(RAIZ / "data" / "dados_frequencia.csv")

freq = df["tipo_atendimento"].value_counts()
total = freq.sum()

sns.set_theme(style="whitegrid")
fig, ax = plt.subplots(figsize=(10, 6))
sns.barplot(x=freq.index, y=freq.values, hue=freq.index,
            palette="mako_r", legend=False, ax=ax)

for i, v in enumerate(freq.values):
    ax.text(i, v + 1.5, f"{v} ({v / total:.1%})", ha="center", fontsize=10)

ax.set_title("Frequência de chamados por tipo de atendimento",
             fontsize=14, weight="bold")
ax.set_xlabel("Tipo de atendimento")
ax.set_ylabel("Número de chamados")
ax.set_ylim(0, freq.max() * 1.12)

fig.tight_layout()
saida = RAIZ / "graficos" / "05_frequencia.png"
fig.savefig(saida, dpi=150)
print(f"Gráfico salvo em {saida}")
