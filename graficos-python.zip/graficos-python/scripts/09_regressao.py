"""Regressão linear: gasto mensal em função da renda mensal."""
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from scipy import stats

RAIZ = Path(__file__).resolve().parent.parent
df = pd.read_csv(RAIZ / "data" / "dados_regressao.csv")

res = stats.linregress(df["renda_mensal"], df["gasto_mensal"])
sinal = "+" if res.intercept >= 0 else "-"
equacao = (f"gasto = {res.slope:.3f} · renda {sinal} {abs(res.intercept):.1f}\n"
           f"R² = {res.rvalue ** 2:.3f}")

sns.set_theme(style="whitegrid")
fig, ax = plt.subplots(figsize=(10, 6))
sns.regplot(data=df, x="renda_mensal", y="gasto_mensal", ci=95,
            scatter_kws={"alpha": 0.6, "s": 45},
            line_kws={"color": "crimson"}, ax=ax)

ax.text(0.04, 0.95, equacao, transform=ax.transAxes, va="top", fontsize=11,
        bbox={"boxstyle": "round", "facecolor": "white", "alpha": 0.9})
ax.set_title("Regressão linear: renda x gasto mensal",
             fontsize=14, weight="bold")
ax.set_xlabel("Renda mensal (R$)")
ax.set_ylabel("Gasto mensal (R$)")

fig.tight_layout()
saida = RAIZ / "graficos" / "09_regressao.png"
fig.savefig(saida, dpi=150)
print(f"Gráfico salvo em {saida}")
