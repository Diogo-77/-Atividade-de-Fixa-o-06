"""Boxplot: distribuição salarial por departamento."""
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

RAIZ = Path(__file__).resolve().parent.parent
df = pd.read_csv(RAIZ / "data" / "dados_boxplot.csv")

ordem = df.groupby("departamento")["salario"].median().sort_values().index

sns.set_theme(style="whitegrid")
fig, ax = plt.subplots(figsize=(10, 6))
sns.boxplot(data=df, x="departamento", y="salario", order=ordem,
            hue="departamento", palette="Set2", legend=False, ax=ax)

ax.set_title("Distribuição salarial por departamento", fontsize=14, weight="bold")
ax.set_xlabel("Departamento (ordenado pela mediana)")
ax.set_ylabel("Salário (R$)")
ax.yaxis.set_major_formatter(lambda v, _: f"{v:,.0f}".replace(",", "."))

fig.tight_layout()
saida = RAIZ / "graficos" / "02_boxplot.png"
fig.savefig(saida, dpi=150)
print(f"Gráfico salvo em {saida}")
