"""Gráfico de dispersão: altura x peso, colorido por sexo."""
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

RAIZ = Path(__file__).resolve().parent.parent
df = pd.read_csv(RAIZ / "data" / "dados_dispersao.csv")

sns.set_theme(style="whitegrid")
fig, ax = plt.subplots(figsize=(10, 6))
sns.scatterplot(data=df, x="altura_cm", y="peso_kg", hue="sexo",
                style="sexo", s=70, alpha=0.8, palette="Set1", ax=ax)

ax.set_title("Relação entre altura e peso", fontsize=14, weight="bold")
ax.set_xlabel("Altura (cm)")
ax.set_ylabel("Peso (kg)")
ax.legend(title="Sexo")

fig.tight_layout()
saida = RAIZ / "graficos" / "03_dispersao.png"
fig.savefig(saida, dpi=150)
print(f"Gráfico salvo em {saida}")
