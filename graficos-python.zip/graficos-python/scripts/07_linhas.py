"""Gráfico de linhas: evolução diária das vendas por loja."""
from pathlib import Path

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

RAIZ = Path(__file__).resolve().parent.parent
df = pd.read_csv(RAIZ / "data" / "dados_linhas.csv", parse_dates=["data"])
df = df.sort_values("data")

sns.set_theme(style="whitegrid")
fig, ax = plt.subplots(figsize=(12, 6))
sns.lineplot(data=df, x="data", y="vendas", hue="loja", style="loja",
             markers=True, dashes=False, palette="Dark2", ax=ax)

ax.set_title("Evolução das vendas por loja (1º trimestre de 2026)",
             fontsize=14, weight="bold")
ax.set_xlabel("Data")
ax.set_ylabel("Vendas")
ax.xaxis.set_major_locator(mdates.MonthLocator())
ax.xaxis.set_major_formatter(mdates.DateFormatter("%b/%Y"))
ax.legend(title="Loja")

fig.tight_layout()
saida = RAIZ / "graficos" / "07_linhas.png"
fig.savefig(saida, dpi=150)
print(f"Gráfico salvo em {saida}")
